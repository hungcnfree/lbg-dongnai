// popup.js - Trợ Lý CSDL v6.0.0 (Hoa Mặt Trời & Nắng Vàng 🌻☀️)
// Bản quyền: © 2026 Cộng Đồng Giáo Viên Chuyển Đổi Số 🌻☀️

const CURRENT_VERSION = '6.0.0';

document.addEventListener('DOMContentLoaded', () => {
  const nameSelect = document.getElementById('cfg-name');
  const userInp = document.getElementById('cfg-username');
  const passInp = document.getElementById('cfg-password');
  const btnToggle = document.getElementById('btn-toggle-pass');
  const btnSave = document.getElementById('btn-save');
  const tkbStatus = document.getElementById('tkb-status-info');
  const btnUpload = document.getElementById('btn-upload-tkb');
  const fileInp = document.getElementById('input-tkb-file');
  const btnReset = document.getElementById('btn-reset-default-tkb');
  const btnCheckVer = document.getElementById('btn-check-version');
  const verResult = document.getElementById('version-check-result');

  async function status(){
    const name=nameSelect.value;
    const list=await LbgHistory.schedules(name);
    tkbStatus.textContent=list.length?list.map(x=>x.refStartDate+' · '+x.filename+' · '+x.lessons.length+' tiết').join(' | '):'Chưa nạp thời khóa biểu';
  }
  chrome.storage.local.get('csdl_teacher_config',({csdl_teacher_config:c})=>{
    if(c){nameSelect.value=c.name;userInp.value=c.username;passInp.value=c.password;}
    status();
  });
  nameSelect.onchange=status;
  btnToggle.onclick=()=>{passInp.type=passInp.type==='password'?'text':'password';};
  btnSave.onclick=async()=>{
    const name=nameSelect.value;
    if(!name)return alert('Chọn giáo viên.');
    await chrome.storage.local.set({activeTeacher:name,csdl_teacher_config:{name,username:userInp.value.trim(),password:passInp.value,mode:'dako',capHoc:'Trung học cơ sở',phuongXa:'Xã Đăk Ơ',truong:'Trường THCS Đăk Ơ (70691515) - Xã Đăk Ơ'}});
    alert('Đã lưu cấu hình.');
  };
  btnUpload.onclick=()=>fileInp.click();
  fileInp.onchange=async()=>{
    const file=fileInp.files[0],name=nameSelect.value;
    fileInp.value='';
    if(!file||!name)return alert('Chọn giáo viên và tệp.');
    try{
      const reader=await import('./schedule-reader.mjs');
      const c=await reader.importSchedule(file,name);
      const date=prompt('Xác nhận ngày hiệu lực YYYY-MM-DD',c.refStartDate);
      if(date===null)return;
      if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||new Date(date+'T00:00:00Z').toISOString().slice(0,10)!==date)throw Error('Ngày chưa hợp lệ.');
      const lines=c.lessons.map(x=>'Thứ '+x.thu+' · '+x.buoi+' · tiết '+x.tiet+' · '+x.mon+' '+x.lop);
      if(!confirm(name+' · '+date+'\n'+lines.join('\n')+'\nLưu phiên bản TKB này?'))return;
      await LbgHistory.save('tkb',name,{teacherName:name,refStartDate:date,filename:file.name,lessons:c.lessons});
      await status();
    }catch(e){alert(e.message);}
  };
  btnReset.onclick=async()=>{
    const name=nameSelect.value;
    const drafts=await LbgHistory.entries('draft',name);
    if(!drafts.length)return alert('Chưa có bản xem trước để đối chiếu.');
    const d=drafts[0];
    if(confirm('Đã kiểm tra trên CSDL và xác nhận tất cả các dòng sau đã ghi đúng? Tuần '+d.week+'\n'+d.lessons.map(x=>x.mon+' '+x.lop+' · PPCT '+x.basePpct).join('\n'))){
      await LbgHistory.save('saved',name,d);
      alert('Đã chốt mốc tuần '+d.week);
    }
  };
  btnCheckVer.onclick=()=>chrome.tabs.create({url:'https://hungcnfree.github.io/lbg-dongnai/'});
});
