const clean = value => String(value ?? '').normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('vi');
export function transpose(rows) {
  const width = rows.reduce((n,row)=>Math.max(n,row.length),0);
  return Array.from({length:width}, (_,col)=>rows.map(row=>row[col] ?? ''));
}
export function pdfGrid(items) {
  const lines = [];
  for (const item of items.filter(i=>i.str?.trim()).sort((a,b)=>b.transform[5]-a.transform[5])) {
    const y = item.transform[5];
    let line = lines.at(-1);
    if (!line || Math.abs(y-line.y)>Math.max(2,item.height*0.3)) {
      line = {y, cells:[]};
      lines.push(line);
    }
    line.cells.push(item);
  }
  const starts = [];
  for (const x of lines.flatMap(l=>l.cells.map(c=>c.transform[4])).sort((a,b)=>a-b)) {
    if (!starts.length || x-starts.at(-1)>4) starts.push(x);
  }
  return lines.map(line=>{
    const row=Array(starts.length).fill('');
    for(const cell of line.cells.sort((a,b)=>a.transform[4]-b.transform[4])){
      const i=starts.findLastIndex(x=>x<=cell.transform[4]);
      row[i]=(row[i]+' '+cell.str).trim();
    }
    return row;
  });
}
export function recognize(grids,teacher,engine) {
  const lessons=new Map();
  let config;
  for(const grid of grids) {
    for(const rows of [grid,transpose(grid)]) {
      const matches=[engine.parseMatrixRows(rows,teacher),engine.parseHorizontalMasterGrid(rows,teacher),engine.parseCsdlTableRows(rows)];
      for(const result of matches){
        const selected=Object.values(result||{}).find(c=>clean(c.teacherName)===clean(teacher));
        if(!selected?.lessons?.length) continue;
        config=selected;
        for(const item of selected.lessons){
          if (!item.mon || !item.lop || item.thu<2 || item.thu>7 || item.tiet<1 || item.tiet>(item.buoi==='CHIEU'?4:5))
            throw Error('Có ô thiếu môn/lớp hoặc vượt số tiết của mẫu CSDL. Kiểm tra lại bảng trước khi nạp.');
          const key=item.stt, previous=lessons.get(key);
          if(previous && (clean(previous.mon)!==clean(item.mon)||clean(previous.lop)!==clean(item.lop))) throw Error('Có hai cách hiểu cho cùng một tiết. Hãy kiểm tra bố cục bảng.');
          lessons.set(key,item);
        }
        break;
      }
    }
  }
  if(!config) throw Error('Chưa nhận diện được bảng của đúng giáo viên. Kiểm tra họ tên và tiêu đề thứ, tiết.');
  return {...config, lessons:[...lessons.values()].sort((a,b)=>a.stt-b.stt),totalLessons:lessons.size};
}
export async function importSchedule(file,teacher) {
  const bytes=await file.arrayBuffer();
  let grids=[];
  if(/\.pdf$/i.test(file.name)){
    const pdf=await import('./pdf.min.mjs');
    pdf.GlobalWorkerOptions.workerSrc=chrome.runtime.getURL('pdf.worker.min.mjs');
    const doc=await pdf.getDocument({data:bytes,isEvalSupported:false,useSystemFonts:true}).promise;
    try {
      for(let i=1;i<=doc.numPages;i++){
        const page=await doc.getPage(i);
        grids.push(pdfGrid((await page.getTextContent()).items));
      }
    } finally {await doc.destroy();}
    if(!grids.some(grid=>grid.length)) throw Error('PDF là bản scan. Hãy xuất PDF có lớp chữ hoặc dùng file Excel gốc.');
    grids=[grids.flat()];
  }else if(/\.xlsx?$/i.test(file.name)){
    const wb=XLSX.read(bytes,{type:'array'});
    grids=wb.SheetNames.map(name=>XLSX.utils.sheet_to_json(wb.Sheets[name],{header:1,raw:false,defval:''}));
  }else throw Error('Chọn file Excel (.xls, .xlsx) hoặc PDF.');
  return recognize(grids,teacher,LbgExcelEngine);
}

