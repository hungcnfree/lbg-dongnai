const LbgHistory = (() => {
  const key = (type,name) => 'lbg6:'+type+':'+name+':';
  async function entries(type,name) {
    const prefix=key(type,name);
    const all=await chrome.storage.local.get(null);
    return Object.entries(all).filter(([k])=>k.startsWith(prefix)).map(([,v])=>v)
      .sort((a,b)=>b.timestamp-a.timestamp);
  }
  async function save(type,name,value) {
    const timestamp=Date.now();
    await chrome.storage.local.set({[key(type,name)+crypto.randomUUID()]:{...value,timestamp}});
  }
  async function schedules(name){
    const list=await entries('tkb',name);
    const {csdl_tkb_config:legacy}=await chrome.storage.local.get('csdl_tkb_config');
    if(legacy?.isNewSchedule && legacy.teacherName===name && legacy.lessons?.length)
      list.push({...legacy,filename:'Excel đã nạp ở phiên bản trước',timestamp:0});
    return list;
  }
  function group(x){return x.mon.trim()+' '+x.lop.trim();}
  async function prepare(name,week) {
    const match=week.text.match(/\((\d+)\/(\d+)\/(\d{4})/);
    if(!match) throw Error('Thiếu ngày đầu tuần.');
    const date=match[3]+'-'+match[2].padStart(2,'0')+'-'+match[1].padStart(2,'0');
    const year=Number(match[3])-(Number(match[2])<8?1:0);
    const schedule=(await schedules(name)).filter(s=>s.refStartDate<=date &&
      Number(s.refStartDate.slice(0,4))-(Number(s.refStartDate.slice(5,7))<8?1:0)===year)
      .sort((a,b)=>b.refStartDate.localeCompare(a.refStartDate)||b.timestamp-a.timestamp)[0];
    if(!schedule) throw Error('Chưa có TKB đã nạp có hiệu lực trong tuần đang chọn.');
    const records=(await entries('saved',name)).filter(x=>x.year===year);
    const target=records.find(x=>x.week===week.num);
    const prior=records.filter(x=>x.week<week.num).sort((a,b)=>b.week-a.week||b.timestamp-a.timestamp);
    const latest=new Map();
    for(const record of prior) if(!latest.has(record.week)) latest.set(record.week,record);
    const anchors=new Map();
    const lessons=[];
    for(const lesson of schedule.lessons.slice().sort((a,b)=>a.stt-b.stt)){
      const k=group(lesson);
      if(!anchors.has(k)){
        let end=0,from=0;
        for(const rec of latest.values()){
          const rows=rec.lessons.filter(x=>group(x)===k);
          if(rows.length){end=Math.max(...rows.map(x=>x.basePpct));from=rec.week;break;}
        }
        if(from!==week.num-1 || !from){
          const input=prompt(k+' — xác nhận PPCT cuối trước tuần '+week.num+
            (from?' (mốc tuần '+from+')':' theo lịch đã ghi trên CSDL')+'. Nhập 0 nếu bắt đầu môn.',from?String(end):'');
          if(input===null) return;
          if(!/^\d{1,4}$/.test(input.trim()))throw Error('Mốc PPCT chưa hợp lệ.');
          end=Number(input);
        }
        anchors.set(k,end);
      }
      const ppct=anchors.get(k)+1;
      anchors.set(k,ppct); lessons.push({...lesson,basePpct:ppct});
    }
    const describe=x=>group(x)+' · PPCT '+x.basePpct;
    const before=new Map((target?.lessons||[]).map(x=>[x.stt,describe(x)]));
    const after=new Map(lessons.map(x=>[x.stt,describe(x)]));
    const lines=[...new Set([...before.keys(),...after.keys()])].sort((a,b)=>a-b).map(stt=>{
      const old=before.get(stt),next=after.get(stt);
      return 'Ô '+stt+' · '+(old===next?'Giữ '+next:(old?old+' → ':'')+(next||'Bỏ'));
    });
    if(!confirm(week.text+'\n'+schedule.filename+'\n'+(target?'Đối chiếu với bản đã chốt':'Chưa có bản chốt tuần này trên máy. Kiểm tra lịch hiện có trên CSDL trước khi nhập.')+'\n\n'+lines.join('\n')+'\n\nTiếp tục nhập?'))return;
    await save('draft',name,{year,week:week.num,lessons});
    return {...schedule,baseWeek:week.num,refStartDate:date,ppctCalibrated:true,lessons};
  }
  return {entries,save,schedules,prepare};
})();
